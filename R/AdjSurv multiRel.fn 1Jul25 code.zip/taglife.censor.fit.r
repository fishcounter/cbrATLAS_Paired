taglife.censor.fit=function(model.in=NULL, censor.time=NULL
	censoring = readline(prompt="Enter name: ")